import logging

# Configure the logging level and format
logging.basicConfig(
    level=logging.INFO,  # Set the logging level here
    # format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
